import type { Metadata } from "next";
import Container from "@/components/container";
import { Companies } from "@/components/companies";
import { CopyEmailInline } from "@/components/copy-email-inline";
import { DottedSeparator } from "@/components/separator";
import { Focus } from "@/components/focus";
import { Subheading } from "@/components/subheading";

export const metadata: Metadata = {
  title: "Free Audit - David Jason",
  description:
    "Get a free audit for your store or business from David Jason.",
  alternates: {
    canonical: "/sponsor",
  },
};

export default function FreeAuditPage() {
  return (
    <>
      <Container className="min-h-screen">
        <Subheading className="mt-4">Free audit</Subheading>
        <div className="text-foreground pt-4 text-base">
          Want to improve your store or business? Get a free audit.
        </div>
        <div className="text-foreground pt-4 text-base">
          I will look at your store or business process and point out areas that
          may need improvement. You do not need to book a call to request the
          audit.
        </div>
        <div className="text-foreground pt-4 text-base">
          Send your store or business details to{" "}
          <CopyEmailInline email="davidjason1820@gmail.com">
            davidjason1820@gmail.com
          </CopyEmailInline>
          .
        </div>
        <DottedSeparator className="my-8" />
        <Focus />
        <DottedSeparator className="my-8" />
        <Companies />
      </Container>
      <Container>
        <DottedSeparator className="my-8" />
      </Container>
    </>
  );
}
