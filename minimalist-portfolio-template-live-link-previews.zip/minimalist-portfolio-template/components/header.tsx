import React from "react";
import { LinkPreview } from "./link-preview";

export const Header = () => {
  return (
    <div>
      <div className="text-foreground pt-4 text-base">
        I am a Shopify, E-commerce and AI Automation Specialist. I work on
        online stores, business systems and useful AI tools, and I share what I
        build and learn on{" "}
        <LinkPreview url="https://x.com/davidjason1820">X</LinkPreview>.
      </div>
      <div className="text-foreground pt-4 text-base">
        I also talk about AI products, vibe coding, e-commerce and the things I
        am learning on my{" "}
        <LinkPreview url="https://davidjason1820.substack.com/">
          Substack
        </LinkPreview>.
      </div>
      <div className="text-foreground pt-4 text-base">
        I have been doing this since 2022, helping businesses improve their
        stores, websites and daily work with simple, useful ideas.
      </div>
    </div>
  );
};
