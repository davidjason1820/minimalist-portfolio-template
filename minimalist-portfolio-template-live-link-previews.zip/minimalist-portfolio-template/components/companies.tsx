import React from "react";
import { Subheading } from "./subheading";
import {
  KlaviyoMark,
  ManusMark,
  PantheonMark,
  ShopifyMark,
  SupabaseMark,
  WebildMark,
} from "./icons/custom";
import { Box } from "./box";

export const Companies = () => {
  const companies = [
    {
      title: "Shopify",
      description: "",
      skeleton: (
        <ShopifyMark className="size-4 text-white drop-shadow-xl drop-shadow-black/40" />
      ),
      boxClassName:
        "bg-linear-to-b from-neutral-400 to-neutral-600 ring-offset-neutral-500",
    },
    {
      title: "Manus",
      description: "",
      skeleton: (
        <ManusMark className="size-4 text-white drop-shadow-xl drop-shadow-black/40" />
      ),
      boxClassName:
        "bg-linear-to-b from-green-400 to-green-600 ring-offset-green-500",
    },
    {
      title: "Klaviyo",
      description: "",
      skeleton: (
        <KlaviyoMark className="size-4 text-white drop-shadow-xl drop-shadow-black/40" />
      ),
      boxClassName:
        "bg-linear-to-b from-violet-400 to-violet-600 ring-offset-violet-500",
    },
    {
      title: "Webild",
      description: "",
      skeleton: (
        <WebildMark className="size-4 text-white drop-shadow-xl drop-shadow-black/40" />
      ),
      boxClassName:
        "bg-linear-to-b from-purple-400 to-purple-600 ring-offset-purple-500",
    },
    {
      title: "Supabase",
      description: "",
      skeleton: (
        <SupabaseMark className="size-4 text-white drop-shadow-xl drop-shadow-black/40" />
      ),
      boxClassName:
        "bg-linear-to-b from-yellow-400 to-yellow-600 ring-offset-yellow-500",
    },
    {
      title: "Pantheon",
      description: "",
      skeleton: (
        <PantheonMark className="size-4 text-white drop-shadow-xl drop-shadow-black/40" />
      ),
      boxClassName:
        "bg-linear-to-b from-indigo-400 to-indigo-600 ring-offset-indigo-500",
    },
  ];
  return (
    <section>
      <Subheading>Companies and platforms I have worked with</Subheading>
      <div className="mt-6 grid grid-cols-2 gap-6 md:grid-cols-3">
        {companies.map((company) => (
          <div key={company.title} className="flex flex-col gap-3">
            <div className="flex items-center gap-2">
              <Box className={company.boxClassName}>{company.skeleton}</Box>
              <p className="text-foreground text-sm font-medium">
                {company.title}
              </p>
            </div>
            {company.description ? (
              <p className="text-foreground/70 text-sm text-pretty">
                {company.description}
              </p>
            ) : null}
          </div>
        ))}
      </div>
    </section>
  );
};
