import React from "react";
import { Subheading } from "./subheading";
import { Box } from "./box";

export const Companies = () => {
  const tools = [
    "Claude",
    "WordPress",
    "Shopify",
    "n8n",
    "Klaviyo",
    "Supabase",
  ];
  return (
    <section>
      <Subheading>Tools I use</Subheading>
      <div className="mt-6 grid grid-cols-2 gap-6 md:grid-cols-3">
        {tools.map((tool) => (
          <div key={tool} className="flex flex-col gap-3">
            <div className="flex items-center gap-2">
              <Box className="bg-linear-to-b from-neutral-400 to-neutral-600 ring-offset-neutral-500">
                <span className="text-xs font-semibold text-white">
                  {tool.slice(0, 1)}
                </span>
              </Box>
              <p className="text-foreground text-sm font-medium">{tool}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
